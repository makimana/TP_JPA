package domain;

import java.util.ArrayList;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import antlr.collections.List;

    @Entity

    public class Chauffage extends IntelligentPeripherik {
        private Residence residence;


        public Chauffage(){

            super();
        }

        @ManyToOne
        public Residence getResidence(){

            return this.residence;
        }
        public void setResidence(Residence residence){
            this.residence = residence;

        }





    }



package service;

import domain.Opower;
import jpa.EntityManagerHelper;

import javax.persistence.*;

import java.util.List;

public class OpowerDAO implements GenericDAO<Opower,Long>{


    EntityManagerHelper manager;

    public OpowerDAO() {
        EntityManagerFactory factory = Persistence
               .createEntityManagerFactory("mysql");

        //GEt From entitymanager helper
       manager.getEntityManager();
    }


    @Override
    public Opower create(Opower opower) {
        EntityTransaction et = manager.getEntityManager().getTransaction();
        et.begin();
        manager.getEntityManager().persist(opower);
        et.commit();
        return  opower;
    }

    @Override
    public Opower read(Long id) {
        return manager.getEntityManager().find(Opower.class, id);
    }


    public List<Opower> readAll() {
        return manager.getEntityManager().createQuery("select o from Opower as o").getResultList();
    }


    @Override
    public Opower update(Opower opower) {
        EntityTransaction et = manager.getEntityManager().getTransaction();
        et.begin();
        manager.getEntityManager().merge(opower);
        et.commit();
        return  opower;
    }


    @Override
    public void delete(Opower opower) {
        EntityTransaction et = manager.getEntityManager().getTransaction();
        et.begin();
        manager.getEntityManager().remove(opower);
        et.commit();
    }

}
